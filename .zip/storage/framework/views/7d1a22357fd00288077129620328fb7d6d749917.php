<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('films.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul style="list-style: none">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php echo e($error); ?>

              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
        <div class="form-group">
            <label for="name">Филм названия:</label>
            <input type="text" class="form-control" id="name" placeholder="Филм названия:" name="name">
            <label for="publication">Публикатция:</label>
            <input type="text" class="form-control" id="publication" placeholder="публикатция:" name="publication">
            <label for="images">Фотография:</label>
            <input type="file" class="form-control" id="images" name="image">
            <label for="janrId">Жанр:</label>
            <select class="form-control" name="janr_id">
                <?php $__currentLoopData = $janrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $janr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option id="janrId" value="<?php echo e($janr->id); ?>"><?php echo e($janr->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="status">Филм опубликоват: </label>
            <input type="checkbox" class="form-control" id="status" placeholder="Филм опубликоват:" name="status">
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\film\resources\views/admin/films/create.blade.php ENDPATH**/ ?>